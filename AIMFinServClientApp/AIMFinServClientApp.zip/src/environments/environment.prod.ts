export const environment = {
    production: true,
    development: false,
    testing: false,
    //for local connection to the API service
    baseAPIUrl: "http://182.75.120.10:9393/AIMFinServAPI/API/",
    baseApplicationURL: "http://182.75.120.10:9393/AimFinServe_Admin/",
    baseClientAppURL: "http://182.75.120.10:9393/AimFinServe_Client/"
};
